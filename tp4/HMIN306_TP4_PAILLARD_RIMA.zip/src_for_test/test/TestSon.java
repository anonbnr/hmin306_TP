package test;

public class TestSon{
     // used in test of TP4
}
