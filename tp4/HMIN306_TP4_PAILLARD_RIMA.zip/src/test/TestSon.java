package test;

public class TestSon extends Test{
     // used in test of TP4
}
