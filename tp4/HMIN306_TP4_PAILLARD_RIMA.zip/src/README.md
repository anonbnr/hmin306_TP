This folder contains the final version of TP4 source code

As TP4 aims to compare two versions of a software, as ArgoUML code is far too consequent, it was tested on a previous version of our TP's code + some classes for different scenario.

You can find v2 to compare with in folder `../src_for_test/`. Code must be in a different project whose path is precised in `main/Main.java` of this project.