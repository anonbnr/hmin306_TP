This folder contains the final version of TP2 source code
