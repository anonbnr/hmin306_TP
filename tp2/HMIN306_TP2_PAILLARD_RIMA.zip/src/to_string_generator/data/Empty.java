package to_string_generator.data;

public class Empty {
	/* METHODS */
	public void display() {
		System.out.println("This is an empty class");
	}
}
